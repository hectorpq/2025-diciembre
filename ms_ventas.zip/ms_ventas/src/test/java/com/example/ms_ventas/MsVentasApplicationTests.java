package com.example.ms_ventas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsVentasApplicationTests {

    @Test
    void contextLoads() {
    }

}
